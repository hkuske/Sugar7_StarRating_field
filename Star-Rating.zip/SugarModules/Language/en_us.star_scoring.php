<?php
$mod_strings['LBL_STAR_SCORING']='Star Scoring';
