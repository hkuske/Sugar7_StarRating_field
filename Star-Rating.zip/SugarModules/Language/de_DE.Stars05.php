<?php
// NOTE => Field Type

$mod_strings['fieldTypes']['Stars05']='Stars05';

?>
